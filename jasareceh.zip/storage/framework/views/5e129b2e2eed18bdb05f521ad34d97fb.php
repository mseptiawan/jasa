<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            Daftar Jasa
        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-6">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">


            
            <div style="display: flex; flex-wrap: wrap; gap: 20px">
                <?php $__empty_1 = true; $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <a href="<?php echo e(route('services.show', $service->slug)); ?>"
                   style="
                        border: 1px solid #ccc;
                        border-radius: 6px;
                        width: 200px;
                        text-decoration: none;
                        color: #000;
                        padding: 10px;
                        display: flex;
                        flex-direction: column;
                    ">
                    <?php
                    $images = json_decode($service->images, true);
                    $mainImage = (!empty($images) && count($images) > 0)
                    ? asset('storage/' . $images[0])
                    : null;

                    $profilePhoto = ($service->user && $service->user->profile_photo)
                    ? asset('storage/' . $service->user->profile_photo)
                    : asset('images/profile-user.png');
                    ?>

                    
                    <?php if($mainImage): ?>
                    <img src="<?php echo e($mainImage); ?>"
                         alt="<?php echo e($service->title); ?>"
                         style="
                            width: 100%;
                            height: 120px;
                            object-fit: cover;
                            border-radius: 4px;
                            margin-bottom: 8px;
                        " />
                    <?php else: ?>
                    <div style="
                            width: 100%;
                            height: 120px;
                            background: #eee;
                            display: flex;
                            align-items: center;
                            justify-content: center;
                            border-radius: 4px;
                            margin-bottom: 8px;
                        ">
                        No Image
                    </div>
                    <?php endif; ?>

                    
                    <h3 style="margin: 0 0 8px 0; font-weight: bold">
                        <?php echo e($service->title); ?>

                    </h3>

                    
                    <div style="display: flex; align-items: center; margin-bottom: 6px">
                        <img src="<?php echo e($profilePhoto); ?>"
                             alt="<?php echo e($service->user->full_name ?? 'N/A'); ?>"
                             style="
                                width: 24px;
                                height: 24px;
                                border-radius: 50%;
                                margin-right: 6px;
                                object-fit: cover;
                            " />
                        <span style="font-size: 14px"><?php echo e($service->user->full_name ?? 'N/A'); ?></span>
                    </div>

                    
                    <p style="color: green; font-weight: bold; margin-top: auto">
                        Rp <?php echo e(number_format($service->price, 0, ',', '.')); ?>

                    </p>

                    
                    <div class="flex mt-1">
                        <?php for($i = 1; $i <= 5;
                           $i++): ?>
                           <?php if($i
                           <=floor($service->avg_rating)): ?>
                            <span class="text-yellow-400">&#9733;</span>
                            <?php elseif($i - $service->avg_rating < 1): ?>
                              <span
                              class="text-yellow-400">&#9733;</span>
                                <?php else: ?>
                                <span class="text-gray-300">&#9733;</span>
                                <?php endif; ?>
                                <?php endfor; ?>
                    </div>

                    <form action="<?php echo e(route('admin.services.toggleStatus', $service->slug)); ?>"
                          method="POST"
                          style="display:inline">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PATCH'); ?>
                        <button type="submit"
                                class="px-2 py-1 rounded <?php echo e($service->status === 'active' ? 'bg-red-500' : 'bg-green-500'); ?>">
                            <?php echo e($service->status === 'active' ? 'Suspend' : 'Enable'); ?>

                        </button>
                    </form>


                </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <p>Tidak ada service untuk ditampilkan.</p>
                <?php endif; ?>
            </div>

        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH /home/mseptiawan/Documents/jasa/resources/views/admin/services/index.blade.php ENDPATH**/ ?>
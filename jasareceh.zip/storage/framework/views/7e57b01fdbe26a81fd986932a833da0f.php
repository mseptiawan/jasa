<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="container mx-auto py-6 max-w-2xl">
        <h1 class="text-2xl font-bold mb-4">Informasi Pembayaran</h1>

        <p>Hai <?php echo e(auth()->user()->name); ?> (<?php echo e(auth()->user()->phone); ?>)</p>
        <p>Total Bayar: <strong>Rp <?php echo e(request('total')); ?></strong></p>
        <p>Metode: <strong><?php echo e(strtoupper(str_replace('_', ' ', request('method')))); ?></strong></p>

        <p>TRX Invoice: <strong>INV-<?php echo e(rand(1000000, 9999999)); ?></strong></p>
        <p>Paket Layanan: <strong><?php echo e($service->title); ?></strong></p>
        <p>Status Pembayaran: <strong>BELUM BAYAR</strong></p>

        <?php if(request('method') == 'virtual_account'): ?>
            <p>No Rekening (VA): <strong>8808 9206 0119 0836</strong></p>
            <p>Silahkan selesaikan pembayaran ke nomor rekening di atas. Internet akan aktif otomatis setelah
                konfirmasi.</p>
        <?php elseif(request('method') == 'qris'): ?>
            <p>Scan QRIS menggunakan aplikasi e-wallet Anda.</p>
        <?php elseif(request('method') == 'credit_card'): ?>
            <p>Masukkan data kartu kredit di halaman selanjutnya untuk melanjutkan pembayaran.</p>
        <?php endif; ?>

        <p class="mt-4">Pastikan anda membayar sebelum masa berlaku habis:
            <strong><?php echo e(now()->addDay()->format('M d Y / H:i:s')); ?></strong>
        </p>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH /home/mseptiawan/Documents/jasa/resources/views/orders/show.blade.php ENDPATH**/ ?>